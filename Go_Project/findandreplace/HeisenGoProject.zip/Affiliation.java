public enum Affiliation
{
    BLACK, WHITE, NONE, DISPUTED;
}