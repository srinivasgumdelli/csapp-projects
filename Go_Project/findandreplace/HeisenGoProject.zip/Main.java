public class Main
{
    public static void main(String [] args)
    {
	TileDrawer window = new TileDrawer();
	window.main(new String[0]);
    }
}
